package com.mycompany.finalassignment;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import javafx.application.Application;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import java.util.Collections;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;

public class App extends Application {

    private Alert alert;

    private static final String FILENAME = "C:\\Users\\Owner\\Documents\\mysql-connector-j-9.1.0\\FinalAssignment\\src\\main\\java\\com\\mycompany\\finalassignment\\award.txt";
    //private static final String COLUMN_SEP = "\t";

    public static ArrayList<Award> getAll() {

        ArrayList awards = new ArrayList<Award>();

        try (BufferedReader in = new BufferedReader(new FileReader(FILENAME))) {
            String line = in.readLine();
            while (line != null) {
                Award award = new Award(line);
                awards.add(award);
                line = in.readLine();
            }
            // close the input stream
            in.close();
            return awards;
        } catch (FileNotFoundException e) {
            System.out.println(FILENAME + " doesn't exist.");
            return null;
        } catch (IOException e) {
            System.out.println(e);
            return null;
        }
    }

    @Override
    public void start(Stage stage) {
       /*
       BorderPane b = new BorderPane();
        b.setStyle( "-fx-border-color: black;");
        */
        ArrayList<Award> myAwards = getAll();
        Button button1 = new Button("1");
        Button button2 = new Button("2");
        Button button3 = new Button("3");
        Button button4 = new Button("4");
        Button button5 = new Button("5");
        Button button6 = new Button("6");
        Button button7 = new Button("7");
        Button button8 = new Button("8");
        Button button9 = new Button("9");
        Button button10 = new Button("10");
        Button button11 = new Button("11");
        Button button12 = new Button("12");
        Button button13 = new Button("13");
        Button button14 = new Button("14");
        Button button15 = new Button("15");
        Button button16 = new Button("16");
        Button button17 = new Button("17");
        Button button18 = new Button("18");
        Button button19 = new Button("19");
        Button button20 = new Button("20");
        Button showAllButton = new Button("Show All");
        Button exitButton = new Button("Exit");
        GridPane grid = new GridPane();

        HBox ButtonBox = new HBox();
        /*
        Image image = new Image("C:\\Users\\Owner\\Documents\\mysql-connector-j-9.1.0\\FinalAssignment\\src\\main\\java\\com\\mycompany\\finalassignment\\keno.PNGkeno.PNG");

         // simple displays ImageView the image as is
         ImageView iv1 = new ImageView();
         iv1.setImage(image);
       
        
         ButtonBox.getChildren().add(iv1);
        */
        Scene scene = new Scene(grid, 760, 400);
        
        grid.add(ButtonBox, 0, 4, 2, 1);
        ButtonBox.getChildren().add(button1);
        ButtonBox.getChildren().add(button2);
        ButtonBox.getChildren().add(button3);
        ButtonBox.getChildren().add(button4);
        ButtonBox.getChildren().add(button5);
        ButtonBox.getChildren().add(button6);
        ButtonBox.getChildren().add(button7);
        ButtonBox.getChildren().add(button8);
        ButtonBox.getChildren().add(button9);
        ButtonBox.getChildren().add(button10);
        ButtonBox.getChildren().add(button11);
        ButtonBox.getChildren().add(button12);
        ButtonBox.getChildren().add(button13);
        ButtonBox.getChildren().add(button14);
        ButtonBox.getChildren().add(button15);
        ButtonBox.getChildren().add(button16);
        ButtonBox.getChildren().add(button17);
        ButtonBox.getChildren().add(button18);
        ButtonBox.getChildren().add(button19);
        ButtonBox.getChildren().add(button20);
        ButtonBox.getChildren().add(showAllButton);
        ButtonBox.getChildren().add(exitButton);

        //exitButton.exitButtonClicked(); --> wrong way
        showAllButton.setOnAction(event -> {
            showAllButtonClicked(myAwards);
        });
        //exitButton.exitButtonClicked(); --> wrong way
        exitButton.setOnAction(event -> {
            exitButtonClicked();
        });

        //example of new stage
        button1.setOnAction(event -> {
            revealAward(myAwards);
            button1.setDisable(true);
        });

        //example of alert
        button2.setOnAction(event -> {
            revealAward(myAwards);
            button2.setDisable(true);
        });

        button3.setOnAction(event -> {
            revealAward(myAwards);
            button3.setDisable(true);
        });
        button4.setOnAction(event -> {
            revealAward(myAwards);
            button4.setDisable(true);
        });
        button5.setOnAction(event -> {
            revealAward(myAwards);
            button5.setDisable(true);
        });
        button6.setOnAction(event -> {
            revealAward(myAwards);
            button6.setDisable(true);
        });
        button7.setOnAction(event -> {
            revealAward(myAwards);
            button7.setDisable(true);
        });
        button8.setOnAction(event -> {
            revealAward(myAwards);
            button8.setDisable(true);
        });
        button9.setOnAction(event -> {
            revealAward(myAwards);
            button9.setDisable(true);
        });
        button10.setOnAction(event -> {
            revealAward(myAwards);
            button10.setDisable(true);
        });
        button11.setOnAction(event -> {
            revealAward(myAwards);
            button11.setDisable(true);
        });
        button12.setOnAction(event -> {
            revealAward(myAwards);
            button12.setDisable(true);
        });
        button13.setOnAction(event -> {
            revealAward(myAwards);
            button13.setDisable(true);
        });
        button14.setOnAction(event -> {
            revealAward(myAwards);
            button14.setDisable(true);
        });
        button15.setOnAction(event -> {
            revealAward(myAwards);
            button15.setDisable(true);
        });
        button16.setOnAction(event -> {
            revealAward(myAwards);
            button16.setDisable(true);
        });
        button17.setOnAction(event -> {
            revealAward(myAwards);
            button17.setDisable(true);
        });
        button18.setOnAction(event -> {
            revealAward(myAwards);
            button18.setDisable(true);
        });
        button19.setOnAction(event -> {
            revealAward(myAwards);
            button19.setDisable(true);
        });
        button20.setOnAction(event -> {
            revealAward(myAwards);
            button20.setDisable(true);
        });
       
        stage.setScene(scene);
         
        stage.show();
    }

    private void exitButtonClicked() {
        alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setHeaderText("Exit!");
        alert.setContentText("Are you sure?");
        ButtonType result = alert.showAndWait().orElse(ButtonType.CANCEL);
        if (result == ButtonType.OK) {
            // User clicked OK
            System.exit(0);
        } else {
            // User clicked Cancel or closed the dialog

        }

    }

    private void showAllButtonClicked(ArrayList<Award> myAwards) {
        /*
        alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText("Invalid Entry!");
        alert.setContentText("textField1 is a required field.");
        alert.showAndWait();
         */
        String contents = "";
        for (Award a : myAwards) {
            contents = contents + a.getItem() + "\n";
        }
        var label = new Label("Award : \n" + contents);
        Stage newStage = new Stage();
        Scene s = new Scene((label), 230, 400, Color.LIGHTBLUE);
        newStage.setScene(s);
        newStage.show();
    }

    /*
        private void button1Clicked() {
        
        alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText("Invalid Entry!");
        alert.setContentText("textField1 is a required field.");
        alert.showAndWait();
         
        Stage newStage = new Stage();
        newStage.show();
    }
     */
    private void revealAward(ArrayList<Award> myAwards) {

        Collections.shuffle(myAwards);
        String item = myAwards.get(0).getItem();
        String content = "You got " + item + "!";
        if(item.equals("$0") ){
            alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setHeaderText("Sorry!");
            alert.setContentText(content);
            alert.showAndWait();
        } else {
        alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setHeaderText("Congratulations!");
        alert.setContentText(content);
        alert.showAndWait();
        }
    }

    public static void main(String[] args) {
        launch();
    }
}
