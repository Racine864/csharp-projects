/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalassignment;



/**
 *
 * @author Owner
 */
public class Award {
    
    String item;

    Award(String item) {
        this.item = item;
    }

    public String getItem() {

        return item;

    }
    
     public void setItem(String item) {

         this.item = item;

    }
    
}

