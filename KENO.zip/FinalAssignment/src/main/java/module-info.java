module com.mycompany.finalassignment {
    requires javafx.controls;
    exports com.mycompany.finalassignment;
}
