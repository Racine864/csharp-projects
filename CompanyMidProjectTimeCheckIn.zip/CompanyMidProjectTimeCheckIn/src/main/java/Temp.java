

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author Owner
 */

public class Temp extends PersonalTimeCard {

    // public static int count;
    public Double temp;

    public Temp() {
        super();
        temp = 0.0;
        count++;

    }

    public Temp(Double temp) {
        super();
        this.temp = temp;
        count++;

    }


    public void setTemp(Double temp) {
        this.temp = temp;
    }

    public Double getTemp() {
        return this.temp;
    }

    public String checkTemp() {

        if (temp >= 104) {
            currentState = "out";

        } else if (70 < temp || temp < 104) {
            currentState = "in";
        } else {
            System.out.println("improper response");
            currentState = "error";

        }
        return "*" + currentState + "*";
    }

    public String displayTempInfo() {
        return super.displayUserInfo() + " " + Double.toString(temp);

    }
}

/*


@Override
public String toString() {
return super.toString() + " by " + author;
}
 */

