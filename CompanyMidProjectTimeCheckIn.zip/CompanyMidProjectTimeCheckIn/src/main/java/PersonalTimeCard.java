/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Owner
 */
public class PersonalTimeCard {

    public String userID;
    public String name;
    public String time;
    public String currentState;
    protected static int count = 0;
   // private String timeCard;

    public PersonalTimeCard() {

        userID = "";
        name = "";
        time = "";
        currentState = "";

    }

    public PersonalTimeCard(String userID, String name, String time, String currentState) {

        this.userID = userID;
        this.name = name;
        this.time = time;
        this.currentState = currentState;

    }

// the set and get methods (setters, getters) for the code variable


    public void setUserID(String userID) {
        this.userID = userID;
    }
    public String getUserID() {
        return userID;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }

    public void setTime(String time) {
        this.time = time;
    }
    public String getTime() {
        return time;
    }


    public void setCurrentState(String currentState) {
        this.currentState = currentState;
    }
    public String getCurrentState() {
        return currentState;
    }

    public String displayUserInfo(){
        return userID + " " + name + " " + time + " " + currentState;
    }

}
