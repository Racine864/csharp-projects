
import java.util.Scanner;

public class MidProjectTimeCheckIn {

    public static void main(String[] args) {


        @SuppressWarnings("empty-statement")

        String myCompanyName = "";
        String myAdminID = "";
        String myAdminPassword = "";
        String mySelection ="";

        String allUserID = "";
        String myUserID = "";
        String allName = "";
        String myName = "";
        String allTemp = "";
        Double myTemp = 0.0;
        String allTime = "";
        String myTime = "";
        String allCurrentState = "";
        String currentState = "";
        int count = 0;

        Scanner sc = new Scanner(System.in);


        System.out.println("What is your company name: ");
        myCompanyName = sc.nextLine();

        System.out.println("What is your Admin ID: ");
        myAdminID = sc.nextLine();

        System.out.println("What is your Admin Password: ");
        myAdminPassword = sc.nextLine();

        Company myCompany = new Company(myCompanyName, myAdminID, myAdminPassword);

        String myMenu = "\nMain Menu:\n 1: User Time Check-In \n 2: Admin → To display all checkin(or admin work.) \n 3: Close (exits program) \n Select your Chose: ";
        String myAdminMenu = "\nAdmin Menu:\n 1: Display All \n 2: Update Admin Profile or Company Name \n 3: Close (exits program) \n Select your Chose: ";
        int choice = 0;
        int adminChoice = 0;

        System.out.println(myCompany.welcomeMessage());
        System.out.print(myMenu);

            try{
                choice = Integer.parseInt(sc.nextLine());
                while(choice != 3) {
                        switch (choice) {
                            case 1 ->{
                                mySelection = "User Time Check-In";
                                System.out.print("User Time Check-In\n ");
                                //Check in case -->Same as MTC SignIN
                                System.out.println("What is your company userID: ");
                                myUserID = sc.nextLine();

                                System.out.println("What is your name: ");
                                myName = sc.nextLine();

                                System.out.println("What is your time: ");
                                myTime = sc.nextLine();
                                Temp myInfo = new Temp(myTemp);
                                System.out.println("What is your temp: ");

                                myTemp = Double.parseDouble(sc.nextLine()); //convert to double --> Validate,
                                System.out.println(myInfo.checkTemp());
                                myInfo.setTemp(myTemp);
                                myInfo.checkTemp();
                                myInfo.setUserID(myUserID);
                                myInfo.setName(myName);
                                myInfo.setTime(myTime);
                                myInfo.setCurrentState(currentState);
                                count = count + 1;

                                allUserID = allUserID + " | " + Integer.toString(count) + ". | " + myInfo.getUserID() + " ";
                                allName = allName + " | " + Integer.toString(count) + ". | " +  myInfo.getName() + " ";
                                allTemp = allTemp + " | " + Integer.toString(count) + ". | " +  myInfo.getTemp() + " ";
                                allTime = allTime + " | " + Integer.toString(count) + ". | " +  myInfo.getTime() + " ";
                                allCurrentState = allCurrentState + " | " + Integer.toString(count) + ". | " +  myInfo.checkTemp();
                                //Keep adding others like MTC signIN

                                System.out.println("Your information is : "  +  myInfo.displayTempInfo());

                            }

                            case 2 -> {
                                mySelection = "Administrator";
                                //Admin Case
                                System.out.println("\nWhat is your Admin ID: ");
                                myAdminID = sc.nextLine();
                                System.out.println("What is your Password: ");
                                myAdminPassword = sc.nextLine();

                                if (myAdminID.equals(myCompany.getAdminID()) && myAdminPassword.equals(myCompany.getAdminPassword()) )  {
                                    System.out.print(myAdminMenu);
                                    adminChoice = Integer.parseInt(sc.nextLine());
                                    while(adminChoice != 3) {

                                        switch (adminChoice) {
                                            case 1 -> {
                                                System.out.print("All Time Check In Information : \n");
                                                //Same as MTC SignIn display all
                                                System.out.println(count + ". \n");
                                                System.out.print(allUserID  + " \n");
                                                System.out.print(allName + " \n");
                                                System.out.print(allTemp + " \n");
                                                System.out.print(allTime + " \n");
                                                System.out.print(allCurrentState + " \n");
                                            }
                                            case 2 -> {
                                                System.out.print("Update Company Information: \n ");
                                                System.out.println("What is your company New name: ");
                                                myCompanyName = sc.nextLine();

                                                System.out.println("What is your new Admin ID: ");
                                                myAdminID = sc.nextLine();

                                                System.out.println("What is your new Admin Password: ");
                                                myAdminPassword = sc.nextLine();

                                                myCompany.setCompany(myCompanyName);
                                                myCompany.setAdminID(myAdminID);
                                                myCompany.setAdminPassword(myAdminPassword);

                                                System.out.print("This is new info : " + myCompany.displayInfo() + "\n");
                                            }

                                            case 3 -> {
                                                System.out.println("Exit admin. \n");
                                            }

                                        }

                                        System.out.print(myAdminMenu);
                                        adminChoice = Integer.parseInt(sc.nextLine());
                                    }
                                }else {
                                    System.out.print("Wrong admin authentication.\n");
                                }

                            }


                            case 3 -> mySelection = "Exit";
                        }
                        //System.out.print(mySelection);
                        System.out.print(myCompany.welcomeMessage() + "\n");
                        System.out.print(myMenu);
                        choice = Integer.parseInt(sc.nextLine());

                }

            } catch (NumberFormatException e) {
                System.out.println("Error! cannot accept string value value.");

            }

            }


}
