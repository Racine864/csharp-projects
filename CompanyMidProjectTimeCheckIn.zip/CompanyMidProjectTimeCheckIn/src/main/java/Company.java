
public class Company {


    private String cname;
    private String adminID;
    private String adminPassword;



    public Company() {

        this.cname = "";
        this.adminID= "";
        this.adminPassword = "";

    }
    public Company(String cname,String adminID, String adminPassword) {

        this.cname = cname;
        this.adminID= adminID;
        this.adminPassword = adminPassword;
    }

    public void setCompany(String cname) {
        this.cname = cname;
    }
    public String getCompany() {
        return cname;
    }

    public void setAdminID(String adminID) {
        this.adminID = adminID;
    }
    public String getAdminID() {
        return adminID;
    }

    public void setAdminPassword(String adminPassword) {
        this.adminPassword = adminPassword;
    }
    public String getAdminPassword() {
        return adminPassword;
    }

    public String displayInfo() {
        return this.cname + " " + this.adminID + " " + this.adminPassword;
    }

    String welcomeMessage() {
        return "Welcome to " + cname;
    }




}
