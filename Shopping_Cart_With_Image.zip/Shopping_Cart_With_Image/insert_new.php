<!DOCTYPE html><html lang="en"> <head> <meta charset="utf-8">
<title> Simple Image Upload </title> </head>
<body>
<h1> Simple Image Upload insert_new.php</h1>
<p>Below is the result: </p>
<?php
// If file upload form is submitted
$status = $statusMsg = '';
if(isset($_POST["submit"])){
$status = 'error';
if(!empty($_FILES["image"]["name"])) {
//We did not validate desciption and price this time to make it easy.
$desc = $_POST['desc'];
$price = $_POST['price'];
// Get file info
$fileName = basename($_FILES["image"]["name"]);
$fileType = pathinfo($fileName, PATHINFO_EXTENSION);
// Allow certain file formats
$allowTypes = array('jpg','png','jpeg','gif');
if(in_array($fileType, $allowTypes)){
$image = $_FILES['image']['tmp_name'];
$imgContent = addslashes(file_get_contents($image));
// sql to insert user input
// Insert image content into database (Another way to run SQL statment)
//Below two lines should be one line.
$insert = $db->query("INSERT into catalogImage (Item_id, imageData, description, price, createdTime)
VALUES (NULL,'$imgContent', '$desc', $price, NOW())");
if($insert){
$status = 'success';
$statusMsg = "File uploaded successfully.";
}else{
$statusMsg = "File upload failed, please try again.";
}
}else{
$statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
}
}else{
$statusMsg = 'Please select an image file to upload.';
}
}
// Display status message
echo $statusMsg;
?>
<p>Click <a href="view.php"> Here </a> to See the result. </p>
</body>
</html>
