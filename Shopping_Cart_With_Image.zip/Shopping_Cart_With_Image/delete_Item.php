<!DOCTYPE html><html lang="en"><head><meta charest="utf-8">
<title> delete_Item.php</title>
</head>
<body>
<h1> All Items saved. </h1>
<?php
include "../include/imageBase.php";
$result = $db->query("SELECT * FROM catalogImage ORDER BY Item_id DESC");
if($result->num_rows > 0){ ?>
<div class="gallery">
<?php
while($row = $result->fetch_assoc()){
echo "ID: ".$row['Item_id']." Desc: ".$row['description']." Price : $".$row['price'];
?>
<img src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($row['imageData']); ?>" width="50" height="50"/>
<br>
<?php
}
?>
</div>
<?php }else{ ?>
<p class="status error">Image(s) not found...</p>
<?php } ?>
<br>
<form method="post" action="delete_Data.php">
Type id to Delete!<br>
ID: <input type="text" name="ID">
<br> <input type="submit">
</form>
<p>Click <a href="shopping.php"> Here </a> to go back previous Main web page. </p>
</body>
</html>