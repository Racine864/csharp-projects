<!DOCTYPE html><html lang="en">
<head> <meta charset="utf-8">
<title>delete Data</title>
</head>
<body>
<h1>delete_Data.php</h1>
<p>Below is the result: </p>
<?php
include "../include/imageBase.php";
// 1. collect value of input field
$idToDelete = $_POST['ID'];
// 2.Generate sql statement to delete a record
$sql = "DELETE FROM catalogImage WHERE Item_id = $idToDelete"; //You can choose id to delete.
//3. Execute SQL
$result = $db->query($sql);
if ($result) {
echo "Record deleted successfully";
} else {
echo "Error deleting record: " . $db->error;
}
$db->close();
?>
<p>Click <a href="shopping.php"> Here </a> to go back previous Main web page. </p>
</body> </html>
