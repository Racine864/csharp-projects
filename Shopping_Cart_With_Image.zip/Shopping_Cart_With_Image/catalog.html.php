<?php
include_once 'helpers.inc.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Product Catalog</title>
<style>
table {
border-collapse: collapse;
}
td, th {
border: 1px solid black;
}
</style>
</head>
<body>
<h1>Welcome to my Shopping Mall!!!</h1>
<p>Click <a href="newitem.html"> Here </a> to Add New Item. </p>
<p>Click <a href="delete_Item.php"> Here </a> to Delete an Item. </p>
<p>Your shopping cart contains <?php
echo count($_SESSION['cart']); ?> items.</p>
<p><a href="?cart">View your cart</a></p>
<table border="1">
<thead>
<tr>
<th>Item Description</th>
<th>Price</th>
<th>Image</th>
</tr>
</thead>
<tbody>
<?php foreach ($items as $item): ?>
<tr>
<td><?php htmlout($item['desc']); ?></td>
<td>$<?php echo number_format($item['price'], 2); ?></td>
<td>
<img src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($item['imageData']); ?>" width="100" height="100" />
</td>
<td>
<form action="" method="post">
<div>
<input type="hidden" name="id" value="<?php htmlout($item['id']); ?>">
<input type="submit" name="action" value="Buy">
</div>
</form>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
<p>All prices are in imaginary dollars.</p>
</body>
</html>
