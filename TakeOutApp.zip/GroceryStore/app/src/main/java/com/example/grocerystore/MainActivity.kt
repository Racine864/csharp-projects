package com.example.grocerystore

import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

import android.util.Log
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.isInvisible
import androidx.core.view.isVisible
import com.google.android.material.switchmaterial.SwitchMaterial

//Racine Hallabrin CIT 2561

class MainActivity : AppCompatActivity() {
    //Racine Hallabrin CIT 2561
    private lateinit var savedValues: SharedPreferences


    var mySize: String = ""
    var myStyle: String = ""
    var allprice = 0
    var myItem1: String = ""
    var allItem1: String = ""

    var myChoice = ""//Raido button

    var myOnion = "" //checkbox
    var myCheese = ""//checkbox
    var myLettuce = ""//checkbox


    lateinit var cheese: CheckBox
    lateinit var CheckShowMore: CheckBox
    lateinit var RadioShowMore: RadioButton
    lateinit var mySwitchMaterial: SwitchMaterial
    lateinit var condomentsInput: EditText
    lateinit var itemsInCartOutPut: TextView
    var itemsInCart = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        savedValues = getSharedPreferences("savedValues", MODE_PRIVATE);


        //Get SharedPreferences object  To save values temporary when we rotate screen
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets

        }

        //You may declare CheckShowMore above onCreate()
        CheckShowMore = findViewById<CheckBox>(R.id.checkbox_Onion)
        CheckShowMore.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                Log.d("CHECKBOXES", "Onion is checked: $isChecked")
                val text = "Onion is checked!"
                itemsInCart = CheckShowMore.text.toString()

                //price += 1
                allprice += 1
                //Beef
                myOnion = "Onion"
                allItem1 += myItem1 + "~ "
                val duration = Toast.LENGTH_SHORT
                val toast = Toast.makeText(this, text, duration) // in Activity
                toast.show()
            } else {

                //Sugar
                //allItem1 != ""
                myOnion = ""
                allprice -= 1
                Log.d("CHECKBOXES", "Onion is unchecked: $isChecked")
                val text = "Onion is unchecked!"
                val duration = Toast.LENGTH_SHORT
                val toast = Toast.makeText(this, text, duration) // in Activity
                toast.show()
            }

        }
//You may use a CheckBox inside onCreate()
        findViewById<CheckBox>(R.id.checkbox_Cheese).setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                //price += 1
                //var vegan  =findViewById<CheckBox>(R.id.checkbox_Cheese)

                allprice += 2
                // myItem1 = "Cheese"
                myCheese = "Cheese"
                allItem1 += myItem1 + "~ "
                Log.d("CHECKBOXES", "Cheese is checked: $isChecked")
                val text = "Cheese is checked!"
                itemsInCart = condomentsInput.text.toString()
                val duration = Toast.LENGTH_SHORT
                val toast = Toast.makeText(this, text, duration) // in Activity
                toast.show()
            } else {
                myCheese = ""
                allprice -= 2
                allItem1 != ""
                Log.d("CHECKBOXES", "Cheese is unchecked: $isChecked")
                val text = "Cheese is unchecked!"
                val duration = Toast.LENGTH_SHORT
                val toast = Toast.makeText(this, text, duration) // in Activity
                toast.show()
            }

        }

        findViewById<CheckBox>(R.id.checkbox_Lettuce).setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {

                //price += 1
                allprice += 3
                myLettuce = "Lettuce"
                allItem1 += myItem1 + "~ "
                Log.d("CHECKBOXES", "lettuce is checked: $isChecked")
                val text = "Lettuce is checked!"
                itemsInCart = condomentsInput.text.toString()
                val duration = Toast.LENGTH_SHORT
                val toast = Toast.makeText(this, text, duration) // in Activity
                toast.show()
            } else {
                allprice -= 3
                myLettuce = ""

                Log.d("CHECKBOXES", "lettuce is unchecked: $isChecked")
                val text = "lettuce is unchecked!"
                val duration = Toast.LENGTH_SHORT
                val toast = Toast.makeText(this, text, duration) // in Activity
                toast.show()
            }

        }




        RadioShowMore = findViewById<RadioButton>(R.id.radio_veg)
        RadioShowMore.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                Log.d("CHECKBOXES", "Vegetarian is checked: $isChecked")
                allprice += 7
                //android:visibility="visible" not in xml
                var cheese = findViewById<CheckBox>(R.id.checkbox_Cheese)
                myCheese = ""
                cheese.isVisible = false
                val text = RadioShowMore.text.toString()
                myChoice = text

                val duration = Toast.LENGTH_SHORT
                val toast = Toast.makeText(this, text, duration) // in Activity
                toast.show()
            } else {
                var cheese = findViewById<CheckBox>(R.id.checkbox_Cheese)

                cheese.isVisible = true
                cheese.isChecked = false
                allprice -= 7
                Log.d("CHECKBOXES", "Vegetarian is unchecked: $isChecked")

            }
        }
//You may use a CheckBox inside onCreate()
        findViewById<RadioButton>(R.id.radio_kosher).setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                Log.d("RADIO", "Kosher is checked: $isChecked")
                val text = findViewById<RadioButton>(R.id.radio_kosher).text.toString()
                allprice += 5
                myChoice = text

                val duration = Toast.LENGTH_SHORT
                val toast = Toast.makeText(this, text, duration) // in Activity
                toast.show()
            } else {
                allprice -= 5
                Log.d("CHECKBOXES", "Kosher is unchecked: $isChecked")

            }
        }
        //You may use a CheckBox inside onCreate()
        findViewById<RadioButton>(R.id.radio_Beef).setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                Log.d("RADIO", "Beef is checked: $isChecked")
                val text = findViewById<RadioButton>(R.id.radio_Beef).text.toString()

                myChoice = text
                allprice += 7
                val duration = Toast.LENGTH_SHORT
                val toast = Toast.makeText(this, text, duration) // in Activity
                toast.show()
            } else {
                allprice -= 7
                Log.d("CHECKBOXES", "Beef is unchecked: $isChecked")

            }
        }

        //You may use a CheckBox inside onCreate()
        findViewById<RadioButton>(R.id.radio_Chicken).setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                Log.d("RADIO", "Chicken is checked: $isChecked")
                val text = findViewById<RadioButton>(R.id.radio_Chicken).text.toString()

                myChoice = text
                allprice += 6
                val duration = Toast.LENGTH_SHORT
                val toast = Toast.makeText(this, text, duration) // in Activity
                toast.show()
            } else {
                Log.d("CHECKBOXES", "Chicken is unchecked: $isChecked")
                allprice -= 6
            }
        }


        //You may use a CheckBox inside onCreate()
        findViewById<RadioButton>(R.id.Small).setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                Log.d("RADIO", "Small is checked: $isChecked")
                val text = findViewById<RadioButton>(R.id.Small).text.toString()

                mySize = text

                val duration = Toast.LENGTH_SHORT
                val toast = Toast.makeText(this, text, duration) // in Activity
                toast.show()
            } else {
                //mySize = ""
                Log.d("CHECKBOXES", "small is unchecked: $isChecked")
                //mySize = "" causes problem
            }
        }

        //You may use a CheckBox inside onCreate()
        findViewById<RadioButton>(R.id.Large).setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                Log.d("RADIO", "Large is checked: $isChecked")
                val text = findViewById<RadioButton>(R.id.Large).text.toString()

                mySize = text
                allprice += 4
                val duration = Toast.LENGTH_SHORT
                val toast = Toast.makeText(this, text, duration) // in Activity
                toast.show()
            } else {
                allprice -= 4
                //mySize = ""
                Log.d("CHECKBOXES", "Large is unchecked: $isChecked")
                //mySize = "" causes problem
            }
        }

        findViewById<Button>(R.id.btnSubmit)
            .setOnClickListener {
/*
                var text1 = "| Style : " + myStyle
                var text2 = "| Size : " + mySize
                 var textResult = additonalItem1 +" " +  text1 +" " + text2 + " "+ totalCost

 */ itemsInCartOutPut = findViewById<TextView>(R.id.cartResults)
                var name = condomentsInput.text.toString()
                findViewById<TextView>(R.id.cartResults).setText(name)


                var additonalItem1 =
                    "Summary : " + name + " " + myChoice + " | " + mySize + " | " + myOnion + " | " + myLettuce + " | " + myCheese


                var totalCost = " | Cost $" + allprice + "."

                var textResult = additonalItem1 + " " + totalCost

                findViewById<TextView>(R.id.LastResults).setText(textResult)
            }

        condomentsInput = findViewById<EditText>(R.id.condoments)



        mySwitchMaterial = findViewById<SwitchMaterial>(R.id.show_Cart)
        mySwitchMaterial.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
// The switch is checked.
                findViewById<CheckBox>(R.id.checkbox_Cheese).isChecked = false
                findViewById<CheckBox>(R.id.checkbox_Onion).isChecked = false
                findViewById<CheckBox>(R.id.checkbox_Lettuce).isChecked = false

                val duration = Toast.LENGTH_SHORT
                val toast = Toast.makeText(this, "Cleared", duration) // in Activity
                toast.show()


            } else {
// The switch isn't checked.
                findViewById<CheckBox>(R.id.checkbox_Cheese).isChecked = true
                findViewById<CheckBox>(R.id.checkbox_Onion).isChecked = true
                findViewById<CheckBox>(R.id.checkbox_Lettuce).isChecked = true

                val duration = Toast.LENGTH_SHORT
                val toast = Toast.makeText(this, "Cleared", duration) // in Activity
                toast.show()
            }
        }
    }


    override fun onPause() {
        val editor = savedValues.edit()
        val condomentsInput: EditText = findViewById(R.id.condoments)
        super.onPause()
        var itemsInCartString = ""
        var condomentsInputString = ""
        condomentsInputString = condomentsInput.text.toString()
        if (condomentsInputString.equals("")) {
            condomentsInputString = ""
        }
        val itemsInCartOutPut: TextView = findViewById(R.id.LastResults)

        itemsInCartString = itemsInCartOutPut.text.toString()

        val nameOutPut: TextView = findViewById(R.id.cartResults)

        var nameOutPutString = nameOutPut.text.toString()

        editor.putString("nameOutPutString", nameOutPutString)
        editor.putString("condomentsInputString", condomentsInputString)
        editor.putString("itemsInCartString", itemsInCartString)
        editor.apply()
    }

    override fun onResume() {
        super.onResume()
        val condomentsInput: EditText = findViewById(R.id.condoments)
        var condomentsInputString: String = ""
        condomentsInputString = savedValues.getString("condomentsInputString", "").toString()
        val ItemsInCartOutput: TextView = findViewById(R.id.LastResults)
        var itemsInCartString: String = ""
        itemsInCartString = savedValues.getString("itemsInCartString", "").toString()


        val nameOutPut: TextView = findViewById(R.id.cartResults)
        var nameOutPutString: String = ""

        nameOutPutString = savedValues.getString("nameOutPutString", "").toString()

//Display Original Values
        condomentsInput.setText(condomentsInputString)
        ItemsInCartOutput.setText(itemsInCartString)
        nameOutPut.setText(nameOutPutString)
//Calulcate and display result
    }
    //another way to connect button to a function
}